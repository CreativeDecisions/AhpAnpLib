# cdfAHPANPLib
All the methods, structs and calculations needed to set up an Analytic Hierarchy Process and/or and Analytic Network Process
