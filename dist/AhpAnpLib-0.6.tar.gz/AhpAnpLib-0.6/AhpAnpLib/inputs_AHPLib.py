from AhpAnpLib import functions_AHPLib as reqLib
from AhpAnpLib import calcs_AHPLib as cdf_calc
from AhpAnpLib import ratings_AHPLib as cdf_rat
from AhpAnpLib import structs_AHPLib as cdf_str
# import functions_AHPLib as reqLib
# import calcs_AHPLib as cdf_calc
# import ratings_AHPLib as cdf_rat
# import structs_AHPLib as cdf_str



def genFullQuest(model,keyword,verb=False):
    questnr=[]
    for cluster in sorted( model.clusters, key=reqLib.op.attrgetter('order')): 

        for nodeFrom in sorted(cluster.nodes, key=reqLib.op.attrgetter('order')): 
            
            connectedClusters=model.retAllClusterConnectionsFromNode(nodeFrom.name)
            for clusterPWC in sorted(connectedClusters, key=reqLib.op.attrgetter('order')):
                i=0
                qset=[]
                # print("Nodes:\n",clusterPWC.nodes)
                for nodeA in sorted(clusterPWC.nodes, key=reqLib.op.attrgetter('order')):
                    j=0
                    # print("NodeA: ",nodeA.nodeID)
                    for nodeB in sorted(clusterPWC.nodes, key=reqLib.op.attrgetter('order')):
                        # print("NodeB: ",nodeB.nodeID)
                        if (nodeA.nodeID!= nodeB.nodeID) and (i<j) and (nodeA in nodeFrom.connectedTo) and (nodeB in nodeFrom.connectedTo):
                            # print("{}-{}".format(i,j))
                            quest="With respect to {}, which one is more {}: {} or {} ? By how much?".format(nodeFrom.name, keyword, nodeA.name, nodeB.name)
                            if verb:
                                print(quest)
                            qset.append(quest)
                        j+=1
                    i+=1
                questnr.append(qset)
                if verb:
                    print("---------------------------------------------------------------------------\n")
    return questnr
def genFirstLineAboveDiagQuest(model,keyword,verb=False):
    questnr=[]
    for cluster in sorted( model.clusters, key=reqLib.op.attrgetter('order')): 

        for nodeFrom in sorted(cluster.nodes, key=reqLib.op.attrgetter('order')): 
            
            connectedClusters=model.retAllClusterConnectionsFromNode(nodeFrom.name)
            for clusterPWC in sorted(connectedClusters, key=reqLib.op.attrgetter('order')):
                i=0
                qset=[]
                # print("Nodes:\n",clusterPWC.nodes)
                for nodeA in sorted(clusterPWC.nodes, key=reqLib.op.attrgetter('order')):
                    j=0
                    # print("NodeA: ",nodeA.name)
                    for nodeB in sorted(clusterPWC.nodes, key=reqLib.op.attrgetter('order')):
                        # print("NodeB: ",nodeB.name)
                        # print("{}-{}".format(i,j),nodeA in nodeFrom.connectedTo,nodeB in nodeFrom.connectedTo)
                        if (nodeA.nodeID!= nodeB.nodeID) and ((i==0)or (i+1==j)) and (nodeA in nodeFrom.connectedTo) and (nodeB in nodeFrom.connectedTo):
                            
                            quest="With respect to {}, which one is more {}: {} or {} ? By how much?".format(nodeFrom.name, keyword, nodeA.name, nodeB.name)
                            if verb:
                                print(quest)
                            qset.append(quest)
                        j+=1
                    i+=1
                questnr.append(qset)
                if verb:
                    print("---------------------------------------------------------------------------\n")
    return questnr
def genFirstLineQuest(model,keyword,verb=False):
    questnr=[]
    for cluster in sorted( model.clusters, key=reqLib.op.attrgetter('order')): 

        for nodeFrom in sorted(cluster.nodes, key=reqLib.op.attrgetter('order')): 
            
            connectedClusters=model.retAllClusterConnectionsFromNode(nodeFrom.name)
            for clusterPWC in sorted(connectedClusters, key=reqLib.op.attrgetter('order')):
                i=0
                qset=[]
                # print("Nodes:\n",clusterPWC.nodes)
                nodeA=clusterPWC.nodes[0]
                j=0
                # print("NodeA: ",nodeA.name)
                for nodeB in sorted(clusterPWC.nodes, key=reqLib.op.attrgetter('order')):
                    # print("NodeB: ",nodeB.name)
                    # print("{}-{}".format(i,j),nodeA in nodeFrom.connectedTo,nodeB in nodeFrom.connectedTo)
                    if (nodeA.nodeID!= nodeB.nodeID) and (i<j) and (nodeA in nodeFrom.connectedTo) and (nodeB in nodeFrom.connectedTo):
                        # print("{}-{}".format(i,j))
                        quest="With respect to {}, which one is more {}: {} or {} ? By how much?".format(nodeFrom.name, keyword, nodeA.name, nodeB.name)
                        if verb:
                            print(quest)
                        qset.append(quest)
                    j+=1
                questnr.append(qset)
                if verb:
                 print("---------------------------------------------------------------------------\n")
                
    return questnr

def genexport4QualtricsQuestFull(filepath,model,keyword,howMuch=True):
    count=1
    with open(filepath, 'w', encoding='UTF8',newline='') as f: 
        f.write("[[AdvancedFormat]]\n")
        for cluster in sorted( model.clusters, key=reqLib.op.attrgetter('order')): 

            for nodeFrom in sorted(cluster.nodes, key=reqLib.op.attrgetter('order')): 
                f.write("[[Block: With respect to: "+nodeFrom.name+"]]\n")
                connectedClusters=model.retAllClusterConnectionsFromNode(nodeFrom.name)
                for clusterPWC in sorted(connectedClusters, key=reqLib.op.attrgetter('order')):
                    i=0

                    # print("Nodes:\n",clusterPWC.nodes)
                    for nodeA in sorted(clusterPWC.nodes, key=reqLib.op.attrgetter('order')):
                        j=0
                        # print("NodeA: ",nodeA.nodeID)
                        for nodeB in sorted(clusterPWC.nodes, key=reqLib.op.attrgetter('order')):
                            # print("NodeB: ",nodeB.nodeID)
                            if (nodeA.nodeID!= nodeB.nodeID) and (i<j) and (nodeA in nodeFrom.connectedTo) and (nodeB in nodeFrom.connectedTo):
                                # print("{}-{}".format(i,j))
                            
                                f.write("\n[[Question:MC:SingleAnswer]]\n")
                                quest1_csv=str(count)+'. With respect to '+nodeFrom.name+ ' which one is more '+keyword+':'+'\n'
                                f.write(quest1_csv) 
                                f.write("\n[[Choices]]\n")
                                
                                ans1=nodeA.name+'\n'
                                f.write(ans1)
                                ans2=nodeB.name+'\n'
                                f.write(ans2)
                                count+=1
                                
                                if(howMuch):
                                    f.write("\n[[Question:MC:Dropdown]]\n")
                                    quest2_csv=str(count)+". By how much?"+'\n'
                                    f.write(quest2_csv)
                                    f.write("\n[[Choices]]\n")
                                    f.write("1\n2\n3\n4\n5\n6\n7\n8\n9\n")
                                    count+=1
                                f.write('\n')
                                
                            j+=1
                        i+=1
def genexport4QualtricsFirstLineAboveDiagQuest(filepath,model,keyword,howMuch=True):
    count=1
    with open(filepath, 'w', encoding='UTF8',newline='') as f:
        f.write("[[AdvancedFormat]]\n")

        for cluster in sorted( model.clusters, key=reqLib.op.attrgetter('order')): 

            for nodeFrom in sorted(cluster.nodes, key=reqLib.op.attrgetter('order')): 
                f.write("[[Block: With respect to: "+nodeFrom.name+"]]\n")
                
                connectedClusters=model.retAllClusterConnectionsFromNode(nodeFrom.name)
                for clusterPWC in sorted(connectedClusters, key=reqLib.op.attrgetter('order')):
                    i=0
                    # f.write("[[Block:"+clusterPWC.name+"]]\n")
                    # print("Nodes:\n",clusterPWC.nodes)
                    for nodeA in sorted(clusterPWC.nodes, key=reqLib.op.attrgetter('order')):
                        j=0
                        # print("NodeA: ",nodeA.nodeID)
                        for nodeB in sorted(clusterPWC.nodes, key=reqLib.op.attrgetter('order')):
                            # print("NodeB: ",nodeB.nodeID)
                            if (nodeA.nodeID!= nodeB.nodeID) and ((i==0)or (i+1==j)) and (nodeA in nodeFrom.connectedTo) and (nodeB in nodeFrom.connectedTo):
                                f.write("\n[[Question:MC:SingleAnswer]]\n")
                                quest1_csv=str(count)+'. With respect to '+nodeFrom.name+ ' which one is more '+keyword+':'+'\n'
                                f.write(quest1_csv) 
                                f.write("\n[[Choices]]\n")
                                
                                ans1=nodeA.name+'\n'
                                f.write(ans1)
                                ans2=nodeB.name+'\n'
                                f.write(ans2)
                                count+=1
                                
                                if(howMuch):
                                    f.write("\n[[Question:MC:Dropdown]]\n")
                                    quest2_csv=str(count)+". By how much?"+'\n'
                                    f.write(quest2_csv)
                                    f.write("\n[[Choices]]\n")
                                    f.write("1\n2\n3\n4\n5\n6\n7\n8\n9\n")
                                    count+=1
                                f.write('\n')
                            j+=1
                        i+=1       
def genexport4QualtricsFirstLineQuest(filepath,model,keyword,howMuch=True):
    count=1
    with open(filepath, 'w', encoding='UTF8',newline='') as f:
        f.write("[[AdvancedFormat]]\n")
        for cluster in sorted( model.clusters, key=reqLib.op.attrgetter('order')): 
            
            for nodeFrom in sorted(cluster.nodes, key=reqLib.op.attrgetter('order')): 
                f.write("[[Block: With respect to: "+nodeFrom.name+"]]\n")
                connectedClusters=model.retAllClusterConnectionsFromNode(nodeFrom.name)
                for clusterPWC in sorted(connectedClusters, key=reqLib.op.attrgetter('order')):
                    i=0
                    qset=[]
                    # print("Nodes:\n",clusterPWC.nodes)
                    nodeA=clusterPWC.nodes[0]
                    j=0
                    # print("NodeA: ",nodeA.nodeID)
                    for nodeB in sorted(clusterPWC.nodes, key=reqLib.op.attrgetter('order')):
                        # print("NodeB: ",nodeB.nodeID)
                        if (nodeA.nodeID!= nodeB.nodeID) and (i<j) and (nodeA in nodeFrom.connectedTo) and (nodeB in nodeFrom.connectedTo):
                                f.write("\n[[Question:MC:SingleAnswer]]\n")
                                quest1_csv=str(count)+'. With respect to '+nodeFrom.name+ ' which one is more '+keyword+':'+'\n'
                                f.write(quest1_csv) 
                                f.write("\n[[Choices]]\n")
                                
                                ans1=nodeA.name+'\n'
                                f.write(ans1)
                                ans2=nodeB.name+'\n'
                                f.write(ans2)
                                count+=1
                                
                                if(howMuch):
                                    f.write("\n[[Question:MC:Dropdown]]\n")
                                    quest2_csv=str(count)+". By how much?"+'\n'
                                    f.write(quest2_csv)
                                    f.write("\n[[Choices]]\n")
                                    f.write("1\n2\n3\n4\n5\n6\n7\n8\n9\n")
                                    count+=1
                                f.write('\n')
                        j+=1

def genexport4GoogleQuestFull(filepath,model,keyword,howMuch=True):
    count=1
    with open(filepath, 'w', encoding='UTF8',newline='') as f:
        writer = reqLib.csv.writer(f)  
        for cluster in sorted( model.clusters, key=reqLib.op.attrgetter('order')): 

            for nodeFrom in sorted(cluster.nodes, key=reqLib.op.attrgetter('order')): 
                
                connectedClusters=model.retAllClusterConnectionsFromNode(nodeFrom.name)
                for clusterPWC in sorted(connectedClusters, key=reqLib.op.attrgetter('order')):
                    i=0

                    # print("Nodes:\n",clusterPWC.nodes)
                    for nodeA in sorted(clusterPWC.nodes, key=reqLib.op.attrgetter('order')):
                        j=0
                        # print("NodeA: ",nodeA.nodeID)
                        for nodeB in sorted(clusterPWC.nodes, key=reqLib.op.attrgetter('order')):
                            # print("NodeB: ",nodeB.nodeID)
                            if (nodeA.nodeID!= nodeB.nodeID) and (i<j) and (nodeA in nodeFrom.connectedTo) and (nodeB in nodeFrom.connectedTo):
                                # print("{}-{}".format(i,j))
                                quest1_csv=["With respect to "+nodeFrom.name+' which one is more '+keyword, nodeA.name, nodeB.name]
                                writer.writerow(quest1_csv)  
                                quest2_csv=["By how much?","1","2","3","4","5","6","7","8","9"]
                                writer.writerow(quest2_csv)                            
                            j+=1
                        i+=1
def genexport4GoogleFirstLineAboveDiagQuest(filepath,model,keyword,howMuch=True):
    count=1
    with open(filepath, 'w', encoding='UTF8',newline='') as f:
        writer = reqLib.csv.writer(f)  

        for cluster in sorted( model.clusters, key=reqLib.op.attrgetter('order')): 

            for nodeFrom in sorted(cluster.nodes, key=reqLib.op.attrgetter('order')): 
                
                
                connectedClusters=model.retAllClusterConnectionsFromNode(nodeFrom.name)
                for clusterPWC in sorted(connectedClusters, key=reqLib.op.attrgetter('order')):
                    i=0
                    # f.write("[[Block:"+clusterPWC.name+"]]\n")
                    # print("Nodes:\n",clusterPWC.nodes)
                    for nodeA in sorted(clusterPWC.nodes, key=reqLib.op.attrgetter('order')):
                        j=0
                        # print("NodeA: ",nodeA.nodeID)
                        for nodeB in sorted(clusterPWC.nodes, key=reqLib.op.attrgetter('order')):
                            # print("NodeB: ",nodeB.nodeID)
                            if (nodeA.nodeID!= nodeB.nodeID) and ((i==0)or (i+1==j)) and (nodeA in nodeFrom.connectedTo) and (nodeB in nodeFrom.connectedTo):
                                quest1_csv=["With respect to "+nodeFrom.name+' which one is more '+keyword, nodeA.name, nodeB.name]
                                writer.writerow(quest1_csv)  
                                quest2_csv=["By how much?","1","2","3","4","5","6","7","8","9"]
                                writer.writerow(quest2_csv)  
                            j+=1
                        i+=1       
def genexport4GoogleFirstLineQuest(filepath,model,keyword,howMuch=True):
    count=1
    with open(filepath, 'w', encoding='UTF8',newline='') as f:
        writer = reqLib.csv.writer(f)  
        for cluster in sorted( model.clusters, key=reqLib.op.attrgetter('order')): 
            
            for nodeFrom in sorted(cluster.nodes, key=reqLib.op.attrgetter('order')): 
               
                connectedClusters=model.retAllClusterConnectionsFromNode(nodeFrom.name)
                for clusterPWC in sorted(connectedClusters, key=reqLib.op.attrgetter('order')):
                    i=0
                    qset=[]
                    # print("Nodes:\n",clusterPWC.nodes)
                    nodeA=clusterPWC.nodes[0]
                    j=0
                    # print("NodeA: ",nodeA.nodeID)
                    for nodeB in sorted(clusterPWC.nodes, key=reqLib.op.attrgetter('order')):
                        # print("NodeB: ",nodeB.nodeID)
                        if (nodeA.nodeID!= nodeB.nodeID) and (i<j) and (nodeA in nodeFrom.connectedTo) and (nodeB in nodeFrom.connectedTo):
                                quest1_csv=["With respect to "+nodeFrom.name+' which one is more '+keyword, nodeA.name, nodeB.name]
                                writer.writerow(quest1_csv)  
                                quest2_csv=["By how much?","1","2","3","4","5","6","7","8","9"]
                                writer.writerow(quest2_csv)  
                        j+=1


def export4ExcelQuestFull(model,filepath,verb=False):
    workbook = reqLib.xlsxwriter.Workbook(filepath)
    worksheet = workbook.add_worksheet()
    worksheet.set_column(0,20,15)

    cell_format_hdTitle  = workbook.add_format({'bold': True,'font_color': 'red', 'font_size':16})
    cell_format_hdTitle.set_pattern(1)
    cell_format_hdTitle.set_bg_color('C3D5FF')
    cell_format_hd  = workbook.add_format({'bold': True,'font_color': 'red'})
    cell_format_hd.set_pattern(1)
    cell_format_hd.set_bg_color('C3D5FF')
    cell_format_hd2  = workbook.add_format({'bold': True,'font_color': 'red'})
    cell_format_hd2.set_pattern(1)
    cell_format_hd2.set_bg_color('#d5ffc3')
    cell_format_hd3  = workbook.add_format({'bold': True,'font_color': 'red'})
    
    
    cell_format_ln  = workbook.add_format({'bold': True,'font_color': 'blue'})
    cell_format_ln.set_border(1)
    cell_format_diag=workbook.add_format()
    cell_format_diag.set_pattern(1)
    cell_format_diag.set_border(1)
    cell_format_diag.set_bg_color('FFFF6B')
    cell_format_block=workbook.add_format()
    cell_format_block.set_pattern(1)
    cell_format_block.set_border(1)
    cell_format_block.set_bg_color('#808080')
    cell_format_dir=workbook.add_format()
    cell_format_dir.set_pattern(1)
    cell_format_dir.set_border(1)
    cell_format_dir.set_bg_color('#ceebd6')
    cell_format_empty  = workbook.add_format()
    cell_format_empty.set_border(1)
    
    row=0
    col=0
    for cluster in sorted( model.clusters, key=reqLib.op.attrgetter('order')):
        for nodeFrom in sorted(cluster.nodes, key=reqLib.op.attrgetter('order')): 

            connectedClusters=model.retAllClusterConnectionsFromNode(nodeFrom.name)
            if(len(connectedClusters)>0):
                worksheet.write(row, 0, nodeFrom.name,cell_format_hdTitle)
                row=row+1
            for clusterPWC in sorted(connectedClusters, key=reqLib.op.attrgetter('order')):
                # print("Nodes:\n",clusterPWC.nodes)
                worksheet.write(row, 0, "Enter judgments for the paiwise comparisons in the matrix or direct values in the green cells",cell_format_hd3)
                worksheet.write(row+1, 0, clusterPWC.name,cell_format_hd2)
                row=row+1
                col=0
                size=0
                for nodeA in sorted(clusterPWC.nodes, key=reqLib.op.attrgetter('order')):
                    # print("NodeA: ",nodeA.nodeID)         
                    
                    if(nodeA in nodeFrom.connectedTo):
                        worksheet.write(row, col+1, nodeA.name,cell_format_ln)
                        worksheet.write(row+col+1, 0, nodeA.name,cell_format_ln)
                        worksheet.write_number(row+col+1, col+1,1.000 ,cell_format_diag)
                        col+=1
                        size+=1
                    worksheet.write(row, size+1, "Direct values",cell_format_ln)
                for a in range(size):
                    for b in range (size):
                        if(a!=b and a>b):
                            worksheet.write(row+a+1,b+1,"",cell_format_block)
                        if(a!=b and a<b):
                            worksheet.write(row+a+1,b+1,"",cell_format_empty)
                    worksheet.write(row+a+1,size+1,"",cell_format_dir)
                # if verb:
                #     print(nodeA.name,size)        
                if verb:
                    print("Saved pairwise comparison matrix for cluster : ",clusterPWC.name, "with respect to node:", nodeFrom.name) 
                row=row+col+1
                    
            row+=1
    workbook.close()
       
def importFromExcel(model,filepath,sheet_name, verbal=False):

    all_excel = reqLib.pd.read_excel (filepath, sheet_name=0) 
    array_excel=all_excel.fillna(0)
    file_len=len(array_excel)
    if(verbal==True):
        print("File Len=", file_len)
    # print("excel",array_excel)
    
    
    row=0
    if(row<file_len-2):
        if(verbal==True):
            print("row:",row)
        for cluster in sorted( model.clusters, key=reqLib.op.attrgetter('order')):
            for nodeFrom in sorted(cluster.nodes, key=reqLib.op.attrgetter('order')): 
                if(row>0 and row <file_len):
                    if(verbal==True):
                        print(row,"with respect to:",array_excel.iat[row,0])
                    model.wrtlabels.append(array_excel.iat[row,0])
                    row+=1
                connectedClusters=model.retAllClusterConnectionsFromNode(nodeFrom.name)

                for clusterPWC in sorted(connectedClusters, key=reqLib.op.attrgetter('order')):
                    # print("Nodes:\n",clusterPWC.nodes)
                    if(verbal==True):
                        print(row,"In cluster:",array_excel.iat[row,2])
                    model.clabels.append(array_excel.iat[row,2])
                    row=row+1

                    size=0
                    for nodeA in sorted(clusterPWC.nodes, key=reqLib.op.attrgetter('order')):
                        if(nodeA in nodeFrom.connectedTo):
                            model.nlabels.append(array_excel.iat[row,0])
                            size+=1
                    row=row+1
                    pc_matrix =  reqLib.np.empty([size, size], dtype = float)
                    #check if there are direct entries, then take them to generate the matrix otherwise use the pw judgments
                    dir_count=0
                    dir_vector=reqLib.np.empty([size], dtype = float)
                    for dir_val in range(size):
                        dir_item=array_excel.iat[dir_val+row,size+1]
                        if(dir_item>0):
                            dir_vector[dir_count]=dir_item
                            dir_count+=1
                            if(verbal):
                                print("-->dir-->",dir_item)
                    if(dir_count==size):
                        if(verbal):
                            print("will not read judgments")
                        pc_matrix=convDirect2PairwiseMatrix(dir_vector,verbal)  
                    else:    
                        for a in range(size):
                            for b in range (size):
                                item=array_excel.iat[a+row,b+1]
                                if a==b:
                                    pc_matrix[a,b]=1.0
                                elif a<b:
                                    pc_matrix[a,b]=item
                                    if(item!=0):
                                        pc_matrix[b,a]=1./item
                                    else:
                                        pc_matrix[b,a]=0
                    if(verbal==True):
                        print(pc_matrix)
                    # if verb:
                    #     print(nodeA.name,size)        
                    model.all_pc_matrices.append(pc_matrix)
                    row=row+size
                    
                row+=1


def convDirect2PairwiseMatrix(vector,verbal=False):
    size=len(vector)
    pc_matrix =  reqLib.np.empty([size, size], dtype = float)
    for i in range(0,size):
        for j in range(0,size):
            pc_matrix[i,j]=vector[i]/vector[j]
            # print("\n",i,vector[i],j,vector[j],pc_matrix[i,j])
    if(verbal==True):
        print("Vector:",vector,"\nPC Matrix:\n",pc_matrix)
    return pc_matrix    

def readRatScaleRPCfile(scaleName,fileName,verbal=False):
    # read a superdecisions generated scale file and return the vector of member names and judgment pc matrix
    with open(fileName, 'r') as file:
        file_contents = file.read()
    raw_lines = file_contents.split('\n')
    file.close()
    names=[]
    judgments=[]
    values=[]
    memberText="ratings newCategory -network $net -criteria $crit -group $group -category {"
    valueText="set values {"
    for line in raw_lines:
        if( memberText in line):
            info = line.split(memberText)[1].strip("}")
            names.append(info)
        if( valueText in line):
            info = line.split(valueText)[1].strip("}")
            judgments=info.split(",")[0]
            input_list = judgments.split()

    # Convert each element to a float using a list comprehension
    fl_judg_list = [float(elem) for elem in input_list]
    nnodes=len(names)
    matrix_judg=cdf_calc.vector2matrix(fl_judg_list,nnodes)
    priorities=cdf_calc.priorityVector(matrix_judg)
    
    indx=0
    for name in names:
        values.append([name,priorities[indx]])
        indx+=1
    scale=cdf_rat.RatScale(scaleName)
    scale.defineScaleByValue(matrix_judg,False,*values)

    if(verbal):
        print("Reading Judgments from file:"+fileName)
        print(names)
        print(fl_judg_list)
        print("nodes:",nnodes)
        print(matrix_judg)
        print(priorities)
    return scale

def readSDMODfile(modelName,fileName,export=False,verbal=False):
    new_model=cdf_str.Model(modelName)

    with open(fileName, 'r') as file:
        file_contents = file.read()
    raw_lines = file_contents.split('\n')
    file.close()
    netText="set net ["
    structureText="c-network readAllCompares -network $net -source {"
    structureStart=0
    cntNd=0
    totNd=0
    cntCl=0
    clusters=[]
    nodes=[]

    if (export):
        f_op=open(modelName+'.py', 'w')
        f_op.write('from AhpAnpLib import inputs_AHPLib as input\nfrom AhpAnpLib import structs_AHPLib as str\nfrom AhpAnpLib import calcs_AHPLib as calc\nfrom AhpAnpLib import ratings_AHPLib as rate\nfrom AhpAnpLib import functions_AHPLib as reqLib\n')
        f_op.write('\nnew_model=str.Model("'+modelName+'")\n')
    #find starting point with interesting data
    for i,line in enumerate(raw_lines):
        if( netText in line):
            #tbd create multiple model objects for multilevel nets
            break
        else:
            if(structureText in line):
                structureStart=i+1
                cntCl=int(raw_lines[structureStart])
            line=structureStart+1
    #read model's  clusters and nodes
    for i in range(0,cntCl):
        component=raw_lines[line]
        line+=1
        clusters.append(component) 
        cl=cdf_str.Cluster(component,i)
        if(export):
            f_op.write('\ncl'+str(i)+'=str.Cluster("'+component+'",'+str(i)+')')
        cntNd=int(raw_lines[line])
        line+=1

        for j in range(0,cntNd):
            component=raw_lines[line]
            line+=1
            nodes.append(component)
            nd=cdf_str.Node(component,j+totNd)
            cl.addNode2Cluster(nd)
            if(export):
                f_op.write('\nnd'+str(i)+'=str.Node("'+component+'",'+str(j+totNd)+')')
                f_op.write('\ncl'+str(i)+'.addNode2Cluster(nd'+str(i)+')')
        totNd+=cntNd
        new_model.addCluster2Model(cl)
        if(export):
            f_op.write('\nnew_model.addCluster2Model(cl'+str(i)+')\n')
    #now add cluster info
    line+=1
    component=raw_lines[line]
    info=reqLib.re.split(r'[,\s]+', component)
    int_info_list = [int(elem) for elem in info if elem.strip()]
    # print(int_info_list)
    matSize=int_info_list[0]
    del int_info_list[0]

    cl_neighbors_labels=[]
    for i,item in enumerate(int_info_list):
        if((i%2)==0):
            cur_cl=clusters[item]
        else:
            cl_neighbors_labels.insert(item,cur_cl)
    line+=1
    cl_neigh=[]
    for clLine in range(0,matSize):
        component=raw_lines[line]
        judgments=component.split(" ")
        cl_neighbors_list = [float(elem) for elem in judgments if elem.strip()]
        cl_neigh.append(cl_neighbors_list)
        line+=1
        
    cl_neighbors_df = reqLib.pd.DataFrame(cl_neigh,cl_neighbors_labels,cl_neighbors_labels)  
    new_model.cluster_neighbors_mtrx=cl_neighbors_df

    #for each cluster read cluster matrix
    # print(cntCl)
    for clMatCnt in range(cntCl):
        cl_df,line=sdmodLines2PwMatrix(new_model,raw_lines,line,f_op,verbal)
        #nodes section
    #find how many node pwc matrices you will need to read
    component=raw_lines[line]
    temp_ln=line
    count_pw=0
    while component!="}":
        if(component==""):
            count_pw+=1
        # print(component)
        temp_ln+=1
        component=raw_lines[temp_ln]
    
    # print(count_pw)
    for ndMatCount in range(count_pw):
        nd_df,line=sdmodLines2PwMatrix(new_model,raw_lines,line,f_op,verbal)
        
        new_model.all_pc_matrices.append(nd_df.to_numpy())
    input_file=new_model.name+"_empty.xlsx"
    input_file_full=new_model.name+"_filledIn.xlsx"
    output_file=new_model.name+"_results.xlsx"

    export4ExcelQuestFull(new_model,input_file,verb=False)
    
    cdf_calc.calcAHPMatricesSave2File(new_model,input_file,output_file,inputFileUse=False,normalbar=False,idealbar=True,verbal=False)
    #add the inputs to an input file to easily modify
    cdf_calc.copyExcelSheet(output_file, input_file_full, "pairwise_comp",False)
    # save pairwise comparison matrices 

    if(verbal):
        # print(raw_lines)
        # print(structureStart)
        print(cntCl)
        print(clusters)
        print(nodes)
        print(cl_neighbors_df)
        new_model.printStruct()
    if(export):
        f_op.write('\nnew_model.printStruct()')
        f_op.write('\ninput.export4ExcelQuestFull(new_model,"py_file_'+input_file+'",verb=False)')
        f_op.write('\ncalc.calcAHPMatricesSave2File(new_model,"'+input_file_full+'","py_file_'+output_file+'",inputFileUse=True,normalbar=False,idealbar=True,verbal=False)')
        f_op.write('\ncalc.copyExcelSheet("py_file_'+output_file+'","py_file_'+input_file_full+'", "pairwise_comp",False)')
        f_op.close()    
    return new_model

def convertJudgVec2Pairwise(my_list,mat_size):
    count=0
    my_df=reqLib.np.ones([mat_size, mat_size], dtype = float)
    for i in range(mat_size):
        for j in range(mat_size):
            if(i<j):
                my_df[i,j]=my_list[count]
                if(my_list[count]!=0):
                    my_df[j,i]=1./my_df[i,j]
                count+=1       
    return my_df

def sdmodLines2PwMatrix(my_model,raw_lines,start_ln,file_op=None,verbal=False):
    line=start_ln
    matID=raw_lines[line]
    if(matID.isdigit()):
        if(verbal):
            print("reading cluster with ID"+str(matID))
    else:
        
        info=reqLib.re.split(r'[,\s]+', matID)
        int_conn_list = [int(elem) for elem in info if elem.strip()]
        par_cluster=my_model.clusters[int_conn_list[0]]
        my_node=my_model.clusters[int_conn_list[0]].nodes[int_conn_list[1]]
        con_cluster=my_model.clusters[int_conn_list[2]]
        if(verbal):
            print(f"Node:{my_node.name} of cluster {par_cluster.name} is connected to cluster {con_cluster.name}")
    
    
    line+= 1
    #tbd the ids in sdmod are not overall are with respect to the node
    component=raw_lines[line]
    info=reqLib.re.split(r'[,\s]+', component)
    int_cl_list = [int(elem) for elem in info if elem.strip()]


    clMatSize=int_cl_list[0]

    del int_cl_list[0]
    #order of clusters in matrix
    cl_labels=[]
    if (clMatSize>0):
        for i,item in enumerate(int_cl_list):
            if((i%2)==0):
                if(matID.isdigit()):
                    cur=my_model.clusters[item]
                else:
                    # print(con_cluster)
                    # print(item)
                    
                    cur=con_cluster.nodes[item]
                    #add connection my_node to cur
                    my_model.addNodeConnectionFromTo(my_node.name,cur.name,False)
                    if(file_op!=None):
                        file_op.write('\nnew_model.addNodeConnectionFromTo("'+my_node.name+'","'+cur.name+'",False)')
            else:
                cl_labels.insert(item,cur.name) 
    # print(cl_labels)
    #this will give me the connection...check if nodes or clusters if cluster the cluster id but if node clA,node of A, clB
    if (clMatSize>1):
        cl_j=[]
        for item in range(clMatSize):
            line+=1
            component=raw_lines[line]
            info=reqLib.re.split(r'[,\s]+', component)
            cl_j_list = [float(elem) for elem in info if elem.strip()]
            # print(cl_j_list)
            cl_j+=cl_j_list
        line+=1
        pc_j_matrix =convertJudgVec2Pairwise(cl_j,clMatSize)
        # cl_df = reqLib.pd.DataFrame(pc_j_matrix,cl_labels,cl_labels)
        cl_df = reqLib.pd.DataFrame(pc_j_matrix)
        if(verbal):
            print(cl_df)
    else:
        cl_df = reqLib.pd.DataFrame([])
        line+=2
    return cl_df,line
