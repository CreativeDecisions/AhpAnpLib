from AhpAnpLib import functions_AHPLib as reqLib
from AhpAnpLib import inputs_AHPLib as cdf_inp

from AhpAnpLib import calcs_AHPLib as cdf_calc

class RatScale:
    id_generator = reqLib.itertools.count(0)
    def __init__(self,scale_name):
        self.name = scale_name
        self.scaleID = next(self.id_generator)
        #members are [name,ideal priority] or [name,1] if no values are given assuming all equal
        self.members=[]
        #val matrix is the pc matrix that would give the ideal priority vector
        self.val_mat=[]

    def defineScaleByValue(self,mat_values=None,verbal=False,*all_values):
        valuesVector=[]
        
        for value in all_values:
            if isinstance(value, list):
                valuesVector.append(value[1])
            else:
                valuesVector.append(1)
        
        valuesIdealVector=cdf_calc.idealVector(valuesVector)
        i=0
        for value in all_values:
            if isinstance(value, list):
                value[1]=valuesIdealVector[i]
                self.members.append(value)
            else:
                self.members.append([value,1])
            i+=1
        if(mat_values is None):
            self.val_mat=cdf_inp.convDirect2PairwiseMatrix(valuesIdealVector)
        else:
            self.val_mat= reqLib.cp.deepcopy(mat_values)

        if(verbal):
            print(all_values)
            print(valuesVector)
            print(self.val_mat)
    
    def __repr__(self):
        labels=[]
        for value in self.members:
            labels.append(value[0])
        scaleDesc="-------------------Rating model scale---------\nName:"+ self.name+"\n"+reqLib.tabulate(self.members, headers=['Member name', 'Value'], tablefmt='orgtbl')+"\n--------------------------------------------\n"+reqLib.tabulate(self.val_mat, headers=labels, tablefmt='orgtbl')
        return scaleDesc


