import functions_AHPLib as reqLib
import calcs_AHPLib as cdf_calc
import inputs_AHPLib as cdf_inp

#cdf_inp.readSDMODfile(Model and File Name,original sdmod file location,do you want to generate py file=True,with or without judgments,do you want verbal=False)

car_model=cdf_inp.readSDMODfile("Choose Best Car","./resources/Car.sdmod",True,True)

# car3lvl_model=cdf_inp.readSDMODfile("Choose Best Car 3Lvl","./resources/Car_3Lvl.sdmod",True,False)
# test_model=cdf_inp.readSDMODfile("Test model","./resources/test.sdmod",True,False)
# burger_model=cdf_inp.readSDMODfile("Hamburger model","./resources/hamburger.sdmod",True,False)
# car_model.printStruct()
