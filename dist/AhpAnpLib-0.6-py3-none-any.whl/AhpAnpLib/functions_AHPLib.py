import numpy as np
import pandas as pd
import copy as cp
import operator as op
import os
from copy import copy
import openpyxl
from matplotlib import pyplot as plt
from openpyxl.drawing.image import Image
from openpyxl.styles import Border, Side, PatternFill, Font, Color
from openpyxl.styles.differential import DifferentialStyle
from openpyxl.formatting.rule import DataBarRule
from shapely.geometry import LineString
import xlsxwriter
from calendar import c
from platform import node
from re import T
from statistics import mode
from pkgutil import ImpImporter
import csv
import itertools
from tabulate import tabulate
from operator import inv
import re

np.set_printoptions(formatter={'float': lambda x: "{0:0.3f}".format(x)})