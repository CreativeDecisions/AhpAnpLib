from setuptools import setup, find_packages

setup(
    name='AhpAnpLib',
    version='0.9',
    description='Analytic Hierarchy Process and Analytic Network Process Library',
    author='Creative Decisions Foundation',
    license='MIT',
    packages=find_packages(),
    install_requires=[
        'matplotlib>=3.5.2',
        'numpy>=1.23.1',
        'openpyxl>=3.0.10',
        'pandas>=1.4.3',
        'shapely>=2.0.0',
        'tabulate>=0.9.0',
        'wheel>=0.37.0',
        'XlsxWriter>=3.0.3'
    ],
)
